const mongoose = require("mongoose");

// const TEMPLATESCHEMA = new mongoose.Schema({

//      Add your schema here

// });